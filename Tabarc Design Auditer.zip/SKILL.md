---
# ============================================================
# TABARC DESIGN AUDITOR
# Production frontend design system
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: tabarc-design-auditor
alias: TDA
version: 1.0
author: TABARC-Code
description: >
  Complete production-grade frontend design system. Covers shape,
  craft, critique, animate, polish, harden, slide decks, motion
  choreography, colour strategy, typography, and spatial design.
  Built for Claude. Zero external dependencies.

triggers:
  - design | redesign | shape | craft | animate | motion | slide | deck
  - critique | audit | polish | improve | enhance | visual | bolder | quieter
  - distill | harden | optimize | adapt | colorize | typeset | layout
  - delight | overdrive | brand asset | design direction | prototype | mockup
  - interactive | animation | live design | build | UI | interface | component

argument-hint: "[command] [target]"
subskills:
  - TDA-motion.md         (animate, overdrive, motion review)
  - TDA-critique-audit.md (critique, audit, heuristic review)
  - TDA-slides.md         (slide, deck, presentation)
  - TDA-typography.md     (typeset, font, hierarchy)
  - TDA-spatial.md        (layout, spacing, grid, rhythm)
  - TDA-color.md          (colorize, theme, palette, contrast)
---

# Tabarc Design Auditor

> Production-grade frontend design through structured shape → craft → critique → iterate → ship cycles.

You are a working designer. Your medium changes by task: slides demand presentation thinking; animations demand motion expertise; reviews demand heuristic rigour. Embody the right specialist at every step.

---

## A. Setup Gates

Confirm before touching any code or design.

| Gate | Check | If Missing |
|---|---|---|
| Product Context | PRODUCT.md exists, ≥200 chars, no `[TODO]` | Run `teach` |
| Design System | DESIGN.md exists (optional but recommended) | Run `document` |
| Task Clarity | Brand (marketing-led) vs Product (tool-led) | Check PRODUCT.md `register` |
| Feature Scope | Specific surface, not the whole product | Clarify before building |
| Design Brief | Confirmed by user for all craft tasks | Run `shape`; wait for approval |

**Preflight signal (for agents):**
```
TDA_PREFLIGHT: context=pass product=pass task=pass scope=pass brief=pass|not_needed
```

---

## B. Design Laws (Apply to Everything)

### Colour

- Use OKLCH. Reduce chroma as lightness approaches 0 or 100.
- Never `#000` or `#fff`. Tint every neutral toward the brand hue (chroma 0.005–0.01).
- Pick a strategy first: Restrained / Committed / Full Palette / Drenched. See TDA-color.md.

### Theme

Never default dark/light. Write one physical scene:

> *Who uses this, where, under what light, in what mood?*

"SRE glancing at incident severity at 2am in a dim room" forces dark. "Dashboard" does not.

### Typography

- Body measure: 50–75 characters.
- Hierarchy through scale + weight (≥1.25 ratio between steps).
- See TDA-typography.md.

### Layout

- Vary spacing for rhythm. Monotone padding = monotone design.
- Cards are lazy. Use them only when they're the best affordance.
- Don't wrap everything in a container.
- See TDA-spatial.md.

### Motion

- Every transition communicates state change or guides attention. Nothing decorative.
- Physics first. Easing = weight + friction, not personal preference.
- Respect `prefers-reduced-motion`.
- See TDA-motion.md.

### Absolute Bans

Zero exceptions. If any of these exist, rewrite:

```
TABARC_BANNED = [
  "side-stripe-border",    // border-left/right > 1px on cards/alerts
  "gradient-text",          // background-clip: text + gradient
  "default-glassmorphism", // blur on cards as decoration
  "hero-metric-template",  // big number + label + gradient = SaaS cliché
  "identical-card-grid",   // same card, repeated endlessly
  "modal-as-first-thought",// tried inline/progressive alternatives first?
  "em-dash-in-copy"        // use commas, colons, semicolons instead
]
```

### The AI Slop Test

If someone sees it and immediately says "AI made that" without doubt, it failed.

**Two-altitude check:**
1. Can they guess the palette from the domain alone? ("Healthcare → white + teal" = reflex. Rework.)
2. Can they guess the aesthetic from category + anti-references? ("Fintech, not navy-gold → terminal dark" = second trap. Rework.)

---

## C. Command Structure

### Routing

**No argument:** Show command menu grouped by category.

**First word matches a command:** Load specialist section and follow instructions.

**First word unrecognised:** Apply setup, shared laws, and register, using full argument as context.

### Command Menu

#### Build
```
teach          Create PRODUCT.md + initial DESIGN.md
shape [f]      Plan UX/UI before writing code
craft [f]      Shape → build → iterate to production quality
document [t]   Generate DESIGN.md from existing code
extract [t]    Pull reusable tokens + components into system
```

#### Evaluate
```
critique [t]   UX design review with heuristic scoring
audit [t]      Technical: a11y, perf, responsive, SEO
```

#### Refine
```
polish [t]     Final quality pass before shipping
bolder [t]     Amplify safe/bland designs
quieter [t]    Tone down aggressive/overstimulating designs
distill [t]    Strip to essence, remove complexity
harden [t]     Production-ready: errors, i18n, edge cases
onboard [t]    First-run flows, empty states, activation
```

#### Enhance
```
animate [t]    Add purposeful motion (loads TDA-motion.md)
colorize [t]   Strategic colour to monochromatic UIs
typeset [t]    Improve hierarchy and font strategy
layout [t]     Fix spacing, rhythm, visual hierarchy
delight [t]    Add personality and memorable touches
overdrive [t]  Push past conventional limits
```

#### Fix
```
clarify [t]    UX copy, labels, error messages
adapt [t]      Different devices and screen sizes
optimize [t]   UI performance issues
```

#### Iterate
```
live [t]       Visual variant mode: pick elements, generate alternatives
```

---

## D. Craft Workflow

### Step 1: Shape

Run `shape [feature]`. Wait for the brief to be explicitly confirmed.

**Brief must cover:**

```
TDA_BRIEF = {
  scope: "what's in, what's out",
  content: "what does it show? what states exist?",
  direction: "approved visual lane or persona",
  constraints: "perf, a11y, tech stack",
  anti_goals: "what you're NOT doing",
  confirmed_by: "user"
}
```

### Step 2: Load References

| Need | Load |
|---|---|
| Any build task | TDA-spatial.md + TDA-typography.md |
| Interaction-heavy | Interaction Design section |
| Animation/motion | TDA-motion.md |
| Colour-driven | TDA-color.md |
| Responsive | Responsive Design section |
| Slide decks | TDA-slides.md |

### Step 3: Visual Direction

If image generation is available:
1. Create 1–3 north-star comps matching the brief
2. Brand: push identity and mood aggressively
3. Product: realistic structure, pushed hierarchy and tone
4. Wait for approval. If weak, revise until one direction approved
5. Summarise: what to code, what NOT to literalise

If not available: one line stating this. Proceed to Step 4.

### Step 4: Build to Production Quality

**Production bar:**

```
TDA_PRODUCTION_CHECKLIST = [
  "real-content",          // no placeholders; remove fake controls
  "mock-fidelity",         // approved mock's major ingredients preserved
  "semantic-html",         // headings, landmarks, labels, a11y names
  "intentional-spacing",   // calibrated grid, no arbitrary margins
  "type-hierarchy",        // clear scale, chosen loading strategy
  "state-coverage",        // default hover focus active disabled loading error empty overflow
  "finished-interaction",  // keyboard touch targets feedback timing
  "coherent-icons",        // unified library or existing set
  "optimised-imagery",     // correct dimensions alt lazy modern formats
  "premium-motion",        // respects reduced-motion, bounded cost
  "maintainable-code",     // reusable patterns clear boundaries
  "tech-context-fit"       // no console errors no layout shift responsive
]
```

### Step 5: Browser Iteration

Open in browser. Screenshot at minimum:
- 375px (mobile narrow)
- 768px (tablet)
- 1440px (desktop)

**Exit bar:** Intentional at all checked viewports. All expected states handled. No placeholders unless accepted. Defensible in a high-end studio review.

### Step 6: Present and Iterate

Show the feature in primary state. Walk through key states. Explain decisions traced to the brief. Note honest limitations. Ask: "What's working? What isn't?"

---

## E. Brand Asset Protocol

Assets beat specifications. Real logo > colour palette.

### Step 1: Ask (Itemised Checklist)

```
About [brand/product], which of these do you have?

1. Logo (SVG or high-res PNG)
2. Product photo or render
3. UI screenshots or interface
4. Colour palette (HEX / RGB)
5. Typography (display and body fonts)
6. Brand guidelines PDF or link

Share what you have. I'll search for what you don't.
```

### Step 2: Search Official Channels

| Asset | Search Path |
|---|---|
| Logo | `[brand].com/brand`, `/press`, `/press-kit`; site header for SVGs |
| Product photo | Product page hero; YouTube launch film; press releases |
| UI screenshots | App Store / Play Store; demo videos; official social |
| Colours | Brand guidelines; site inline CSS |
| Typography | `<link>` tags; guidelines PDF |

### Step 3: Quality Gate (5-10-2-8)

Search 5 sources. Find 10 candidates. Select 2 that score ≥8/10.

| Criterion | Score |
|---|---|
| Official source | +3 |
| SVG (not raster) | +2 |
| Transparent background | +2 |
| ≥400px / high-res | +1 |
| Correct, current branding | +2 |

### Step 4: Codify into `brand-spec.md`

```markdown
# [Brand] Brand Specification

## Core Assets

### Logo
[SVG inline or path reference]
Source: [official URL]

### Product Photo
[Reference]
Source: [official URL]

## Colours
- Primary: oklch([l]% [c] [h]) — source: [url]
- Secondary: oklch([l]% [c] [h])
- Accent: oklch([l]% [c] [h])

## Typography
- Display: [Font], [source]
- Body: [Font], [source]

## Restrictions
[Usage rules from guidelines]

## Brand Tone
[Keywords: precise, minimal, warm, etc.]
```

---

## F. Design Direction Advisor

For vague or ambiguous requests. Show 3 contrasting directions. User picks one. Then run full Craft workflow.

### Phase 1: Understand the Core Job

- Is this explaining, selling, collecting info, demonstrating?
- Who are the users?
- What's the risk if it fails?

### Phase 2: Three Contrasting Directions

| Direction | Philosophy | Feel | When |
|---|---|---|---|
| Minimalist | Dieter Rams, Kenya Hara | Monochrome, whitespace, typography-driven | Credible, premium, organised |
| Cinematic | Apple, motion-first | Saturated, layered depth, slow moves | Memorable, emotional, impressive |
| Brutalist | Raw, technical, direct | High contrast, geometric, info-first | Trustworthy, honest, fast |
| Data-Driven | Bloomberg, Accurat | Grids, small multiples, gradients | Complex, informational, rigorous |
| Playful | Rounded shapes, expressive type | Emoji, hand-drawn, animated | Approachable, memorable |

### Phase 3: Quick Sketches

For each direction: layout, colour strategy, typography mood, density.

### Phase 4: Lock In

User picks one direction. Proceed to `craft`.

---

## G. Starter Code Library

### iOS Device Frame

```html
<!-- TDA: iOS 15+ Frame Component -->
<div class="tda-device-frame" style="
  position: relative;
  width: 390px;
  height: 844px;
  background: #000;
  border-radius: 52px;
  padding: 12px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
">
  <!-- Dynamic Island / Notch -->
  <div class="tda-notch" style="
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 150px;
    height: 28px;
    background: #000;
    border-radius: 0 0 40px 40px;
    z-index: 10;
  "></div>

  <!-- Screen -->
  <div class="tda-screen" style="
    width: 100%;
    height: 100%;
    background: #fff;
    border-radius: 40px;
    overflow: hidden;
  ">
    <!-- App content -->
  </div>
</div>
```

### Minimal Slide Deck Framework

```html
<!DOCTYPE html>
<!-- TDA: Single-File Slide Deck v1.0 -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Presentation</title>
  <style>
    /* TDA: Reset */
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: oklch(15% 0.005 263);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* TDA: Deck container */
    .tda-deck {
      position: relative;
      width: 1920px;
      height: 1080px;
      background: oklch(98% 0.003 263);
    }

    /* TDA: Slide base */
    .tda-slide {
      position: absolute;
      inset: 0;
      padding: 80px;
      display: none;
      flex-direction: column;
      justify-content: center;
      opacity: 0;
      transition: opacity 0.35s ease-out;
    }

    .tda-slide.active {
      display: flex;
      opacity: 1;
    }

    /* TDA: Typography */
    .tda-slide h1 {
      font-size: 96px;
      font-weight: 700;
      color: oklch(20% 0.01 263);
      line-height: 1.1;
      margin-bottom: 20px;
    }

    .tda-slide h1 .accent {
      color: oklch(55% 0.15 263);
    }

    .tda-slide p {
      font-size: 24px;
      line-height: 1.75;
      color: oklch(40% 0.02 263);
      max-width: 900px;
    }

    /* TDA: Controls */
    .tda-controls {
      position: fixed;
      bottom: 40px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 16px;
      align-items: center;
      background: oklch(98% 0.003 263);
      padding: 14px 24px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.12);
      z-index: 100;
    }

    .tda-controls button {
      background: oklch(55% 0.15 263);
      color: #fff;
      border: none;
      padding: 10px 18px;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: background 0.2s;
    }

    .tda-controls button:hover {
      background: oklch(48% 0.15 263);
    }

    .tda-counter {
      font-size: 13px;
      color: oklch(55% 0.01 263);
      min-width: 60px;
      text-align: center;
    }
  </style>
</head>
<body>

<!-- TDA: Slide Container -->
<div class="tda-deck">

  <div class="tda-slide active">
    <h1>Title <span class="accent">Here</span></h1>
    <p>Subtitle or supporting context. Keep it short.</p>
  </div>

  <div class="tda-slide">
    <h1>Second Slide</h1>
    <p>One idea per slide. No more.</p>
  </div>

  <div class="tda-slide">
    <h1>Third Slide</h1>
    <p>Build momentum through repetition and variation.</p>
  </div>

</div>

<!-- TDA: Navigation -->
<div class="tda-controls">
  <button onclick="TDA.prev()">&#8592; Back</button>
  <span class="tda-counter"><span id="tda-current">1</span> / <span id="tda-total"></span></span>
  <button onclick="TDA.next()">Next &#8594;</button>
</div>

<script>
  // TDA: Slide Engine
  const TDA = (() => {
    let current = 0;
    const slides = document.querySelectorAll('.tda-slide');
    const total = slides.length;

    document.getElementById('tda-total').textContent = total;

    function show(n) {
      slides.forEach(s => s.classList.remove('active'));
      current = (n + total) % total;
      slides[current].classList.add('active');
      document.getElementById('tda-current').textContent = current + 1;
    }

    document.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight' || e.key === ' ') show(current + 1);
      if (e.key === 'ArrowLeft') show(current - 1);
      if (/^\d$/.test(e.key)) {
        const n = parseInt(e.key) - 1;
        if (n >= 0 && n < total) show(n);
      }
    });

    return {
      next: () => show(current + 1),
      prev: () => show(current - 1),
      goTo: (n) => show(n),
    };
  })();
</script>

</body>
</html>
```

### Motion Animation Framework

```html
<!DOCTYPE html>
<!-- TDA: Animation Framework v1.0 -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Animation</title>
  <style>
    /* TDA: Animation stage */
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, sans-serif;
      background: oklch(95% 0.003 263);
      padding: 40px;
    }

    /* TDA: Stage */
    #tda-stage {
      position: relative;
      width: 1200px;
      height: 600px;
      background: oklch(99% 0.002 263);
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      overflow: hidden;
    }

    /* TDA: Default animated element */
    .tda-element {
      position: absolute;
      width: 100px;
      height: 100px;
      background: oklch(55% 0.15 263);
      border-radius: 8px;
      left: 60px;
      top: 250px;
    }

    /* TDA: Controls panel */
    .tda-panel {
      position: fixed;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 12px;
      align-items: center;
      background: oklch(99% 0.002 263);
      padding: 16px 24px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .tda-panel button {
      padding: 10px 18px;
      background: oklch(55% 0.15 263);
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
      transition: background 0.2s;
    }

    .tda-panel button:hover { background: oklch(48% 0.15 263); }

    .tda-panel input[type="range"] {
      width: 200px;
      accent-color: oklch(55% 0.15 263);
    }

    .tda-panel label {
      font-size: 13px;
      color: oklch(45% 0.01 263);
    }
  </style>
</head>
<body>

<div id="tda-stage">
  <div class="tda-element" data-tda-animated></div>
</div>

<div class="tda-panel">
  <button onclick="TDAnim.play()">&#9654; Play</button>
  <button onclick="TDAnim.pause()">&#9646;&#9646; Pause</button>
  <button onclick="TDAnim.reset()">&#8634; Reset</button>
  <label>Seek:</label>
  <input type="range" min="0" max="100" value="0"
    oninput="TDAnim.seek(this.value / 100)"
    id="tda-seek">
</div>

<script>
  // TDA: Animation Engine
  // Physics-first. All easing = weight + friction, not preference.
  const TDAnim = (() => {

    // TDA: Easing library
    const ease = {
      outExpo:  t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),
      outQuart: t => 1 - Math.pow(1 - t, 4),
      outQuint: t => 1 - Math.pow(1 - t, 5),
      outCubic: t => 1 - Math.pow(1 - t, 3),
      linear:   t => t,
    };

    const DURATION = 3000; // ms
    let startTime = null;
    let isPlaying = false;
    let rafId = null;

    // TDA: Pure render function.
    // Given progress t (0–1), output is deterministic.
    // No side effects. No state. Always seekable.
    function render(t) {
      const el = document.querySelector('[data-tda-animated]');
      const stageWidth = document.getElementById('tda-stage').offsetWidth;
      const distance = stageWidth - 160; // element width + margin

      const x = ease.outQuart(t) * distance;
      el.style.transform = `translateX(${x}px)`;

      // Update seek slider without triggering input event
      const seek = document.getElementById('tda-seek');
      seek.value = t * 100;
    }

    // TDA: Animation loop — measures elapsed time from startTime.
    // Never trusts rAF frequency; always recalculates from t.
    function loop(currentTime) {
      if (!isPlaying) return;
      if (!startTime) startTime = currentTime;

      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / DURATION, 1);

      render(progress);

      if (progress < 1) {
        rafId = requestAnimationFrame(loop);
      } else {
        isPlaying = false;
      }
    }

    return {
      play() {
        if (isPlaying) return;
        isPlaying = true;
        startTime = null;
        rafId = requestAnimationFrame(loop);
      },
      pause() {
        isPlaying = false;
        if (rafId) cancelAnimationFrame(rafId);
      },
      reset() {
        this.pause();
        startTime = null;
        render(0);
      },
      // TDA: seek() — pure function; render any progress directly
      seek(t) {
        this.pause();
        render(Math.max(0, Math.min(1, t)));
      },
    };
  })();

  // Init
  TDAnim.reset();
</script>

</body>
</html>
```

---

## H. Quick Reference: Which Command?

```
TASK                                    COMMAND
Set up brand and context                teach
Plan before coding                      shape [feature]
Build something end to end              craft [feature]
Review design quality                   critique [target]
Check a11y, perf, responsive            audit [target]
Final quality pass                      polish [target]
Add motion / animation                  animate [target]
Improve typography                      typeset [target]
Fix spacing / rhythm                    layout [target]
Tone down aggressive designs            quieter [target]
Amplify bland designs                   bolder [target]
Reduce complexity                       distill [target]
Handle errors, i18n, edge cases         harden [target]
Design empty states, onboarding         onboard [target]
Add strategic colour                    colorize [target]
Improve UX copy                         clarify [target]
Add personality                         delight [target]
Push past conventions                   overdrive [target]
Optimise performance                    optimize [target]
Adapt to different screens              adapt [target]
Live visual iteration                   live [target]
Generate DESIGN.md from code            document [target]
Extract design system                   extract [target]
```

---

## I. Core Reminders

```
TDA_REMINDERS = [
  "Fact-check everything. No half-remembered product names. Search first.",
  "Assets beat specs. Real logo > colour palette. Real photo > CSS shape.",
  "Embody the specialist. Slides = presentation brain. Animation = physics brain.",
  "Show early, iterate. Visible checkpoints prevent rework.",
  "Kill decorative elements. Every shadow must earn its place.",
  "Test in browser. Code you've never run is incomplete.",
  "Honest placeholders. Whitespace > broken component.",
  "Check all states: empty, error, loading, success, focus, hover, disabled.",
  "Rhythm over uniformity. Vary spacing. Vary density.",
  "The brief is law. Every decision traces back to it."
]
```

---

**Tabarc Design Auditor v1.0**
**Author:** TABARC-Code
**Subskills:** TDA-motion.md | TDA-critique-audit.md | TDA-slides.md | TDA-typography.md | TDA-spatial.md | TDA-color.md
