---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Color & Contrast
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-color
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Colour strategy for TDA. OKLCH-first palette design, four
  strategy levels, neutral tinting, contrast rules, theme
  architecture, and semantic colour roles.

triggers:
  - colorize | colour | color | palette | theme | contrast
  - dark mode | light mode | brand colour | tint | saturation
  - OKLCH | hue | chroma | lightness | accessibility contrast
---

# TDA: Color & Contrast

> Colour is not applied. Colour is assigned.
> Every colour must answer: what job does this colour do?
> Before you pick, decide its role and intensity.

---

## Four Strategy Levels

Pick one before doing anything else.

### Level 1: Restrained (Default for Product)

```
Composition: Tinted neutrals + one accent ≤10% of surface
Use when:    Tool or app, data-heavy, professional/corporate
```

```css
/* TDA: Restrained palette example */
:root {
  --tda-bg:      oklch(98% 0.003 263); /* Near-white, blue tint */
  --tda-surface: oklch(95% 0.005 263);
  --tda-text:    oklch(20% 0.01 263);  /* Near-black, blue tint */
  --tda-muted:   oklch(55% 0.02 263);
  --tda-accent:  oklch(55% 0.15 263);  /* CTA and focus only */
}
```

### Level 2: Committed (Default for Brand)

```
Composition: One saturated colour carries 30–60% of surface
Use when:    Marketing, landing pages, emotional storytelling
```

```css
/* TDA: Committed palette example */
:root {
  --tda-primary: oklch(55% 0.15 263); /* Carries the design */
  --tda-bg:      oklch(20% 0.005 263);
  --tda-text:    oklch(95% 0.005 263);
  --tda-cta:     oklch(70% 0.15 45);  /* Contrasting accent */
}
```

### Level 3: Full Palette (Data / Complex Information)

```
Composition: 3–4 named colours, each used deliberately
Use when:    Data visualisation, topic-coded educational content
```

```css
/* TDA: Full palette — semantic roles, not colour names */
:root {
  --tda-success: oklch(70% 0.18 155); /* Green */
  --tda-warning: oklch(70% 0.15 45);  /* Amber */
  --tda-error:   oklch(55% 0.18 25);  /* Red */
  --tda-info:    oklch(60% 0.1 263);  /* Blue */
  --tda-neutral: oklch(50% 0 0);      /* Gray */
}
```

### Level 4: Drenched (Immersive)

```
Composition: The surface IS the colour
Use when:    Brand hero, campaign page, product launch
```

```css
/* TDA: Drenched — colour as environment */
:root {
  --tda-bg:      oklch(20% 0.005 270); /* Dark, saturated */
  --tda-primary: oklch(70% 0.18 155);  /* Strong teal, 40% of surface */
  --tda-gold:    oklch(80% 0.15 85);   /* Gold accent, 20% */
  --tda-text:    oklch(97% 0.002 270); /* Near-white */
}
```

---

## OKLCH: Always Use This

```
oklch(lightness% chroma hue)

  lightness: 0% (black) → 100% (white)
  chroma:    0 (gray) → 0.4 (max saturation)
  hue:       0–360°
```

### Reference Conversions

```css
/* TDA: Common hex → OKLCH */
/* #ffffff */ oklch(100% 0 0)
/* #000000 */ oklch(0% 0 0)
/* #2563eb */ oklch(55% 0.15 263)  /* Blue */
/* #ef4444 */ oklch(55% 0.18 25)   /* Red */
/* #10b981 */ oklch(70% 0.18 155)  /* Teal */
/* #f59e0b */ oklch(75% 0.16 65)   /* Amber */
/* #8b5cf6 */ oklch(55% 0.18 292)  /* Purple */
```

### Why OKLCH Over Hex

```
TDA_OKLCH_REASONS = [
  "Perceptually uniform: same chroma looks equally saturated to human eyes",
  "Accessible by default: adjust lightness without breaking saturation",
  "Predictable: hue stays stable across lightness adjustments",
  "Dark mode: adjust one number instead of recalculating hex"
]
```

---

## The Neutral Tinting Rule

Never use pure white or pure black. Tint every neutral toward the brand hue.

```css
/* TDA: Neutral tinting */

/* Bad: pure white and black, no cohesion */
body { background: #ffffff; color: #000000; }

/* Good: tinted toward brand hue */
body {
  background: oklch(98% 0.003 263); /* White with blue ghost */
  color: oklch(18% 0.008 263);      /* Black with blue ghost */
}

/* TDA: Tint intensity guideline */
/* chroma 0.002–0.005: barely noticeable, feels cohesive */
/* chroma 0.01: noticeable on close inspection */
/* chroma >0.02: clearly tinted */
```

---

## Building a Palette

### Step 1: Choose Brand Hue (0–360°)

```
TDA_HUE_REFERENCE = {
  blue:   "250–270°",
  purple: "280–300°",
  teal:   "180–200°",
  green:  "140–160°",
  yellow: "80–100°",
  orange: "30–50°",
  red:    "15–25°",
  pink:   "340–360°"
}
```

### Step 2: Lightness Ladder (At Your Hue)

```css
/* TDA: Palette from hue 263 (blue) */
:root {
  --tda-263-100: oklch(98% 0.002 263); /* Near-white */
  --tda-263-80:  oklch(85% 0.015 263); /* Light */
  --tda-263-60:  oklch(65% 0.08 263);  /* Medium-light */
  --tda-263-50:  oklch(55% 0.15 263);  /* Saturated (accent) */
  --tda-263-40:  oklch(40% 0.12 263);  /* Dark */
  --tda-263-20:  oklch(22% 0.06 263);  /* Near-black */
}
```

### Step 3: Chroma Rule (Critical)

```
TDA_CHROMA_RULE:
  Reduce chroma as lightness approaches 0% or 100%.
  
  Correct:
    oklch(98% 0.002 263)  — light + low chroma = clean
    oklch(50% 0.15 263)   — medium + high chroma = saturated
    oklch(10% 0.04 263)   — dark + low chroma = clear
    
  Wrong:
    oklch(98% 0.15 263)   — light + high chroma = garish
    oklch(5% 0.2 263)     — dark + high chroma = muddy
```

---

## Contrast Rules

```
TDA_CONTRAST_STANDARDS = {
  "WCAG AA body":       "4.5:1 minimum",
  "WCAG AA large text": "3:1 minimum (>=18px or >=14px bold)",
  "WCAG AAA body":      "7:1 minimum",
  "WCAG AAA large":     "4.5:1 minimum"
}
```

```css
/* TDA: Safe contrast pairs */

/* Light mode — body text */
.tda-body {
  color: oklch(20% 0.01 263);      /* ~12:1 on oklch(98% 0.003 263) */
  background: oklch(98% 0.003 263);
}

/* Dark mode — body text */
.tda-dark .tda-body {
  color: oklch(95% 0.005 263);     /* ~11:1 on oklch(15% 0.005 263) */
  background: oklch(15% 0.005 263);
}

/* TDA: Interactive accent — check contrast for each use */
/* CTA on light background */
.tda-cta {
  background: oklch(55% 0.15 263); /* Check: ~3.5:1 on white */
  color: #fff;                      /* Check: ~5.5:1 on this bg */
}
```

**Checker:** https://webaim.org/resources/contrastchecker/

---

## Theme Architecture (CSS Variables)

```css
/* ============================================================
 * TDA: Theme architecture
 * All colours via CSS variables — never hardcoded hex
 * ============================================================ */

:root {
  /* TDA: Core semantic roles */
  --tda-bg-primary:   oklch(98% 0.003 263);
  --tda-bg-secondary: oklch(94% 0.005 263);
  --tda-surface:      oklch(99% 0.002 263);

  --tda-text-primary:   oklch(20% 0.01 263);
  --tda-text-secondary: oklch(45% 0.015 263);
  --tda-text-muted:     oklch(62% 0.01 263);

  --tda-accent:         oklch(55% 0.15 263);
  --tda-accent-hover:   oklch(48% 0.15 263);
  --tda-accent-subtle:  oklch(90% 0.04 263);

  --tda-border:         oklch(88% 0.008 263);
  --tda-border-strong:  oklch(70% 0.015 263);

  /* TDA: Status colours */
  --tda-success:  oklch(70% 0.18 155);
  --tda-warning:  oklch(70% 0.15 65);
  --tda-error:    oklch(55% 0.18 25);
  --tda-info:     oklch(60% 0.1 263);
}

/* TDA: Dark mode */
@media (prefers-color-scheme: dark) {
  :root {
    --tda-bg-primary:   oklch(15% 0.005 263);
    --tda-bg-secondary: oklch(20% 0.006 263);
    --tda-surface:      oklch(22% 0.006 263);

    --tda-text-primary:   oklch(95% 0.005 263);
    --tda-text-secondary: oklch(75% 0.01 263);
    --tda-text-muted:     oklch(55% 0.01 263);

    /* TDA: Accent is slightly brighter in dark mode */
    --tda-accent:       oklch(60% 0.14 263);
    --tda-accent-hover: oklch(65% 0.14 263);

    --tda-border:        oklch(32% 0.01 263);
    --tda-border-strong: oklch(45% 0.015 263);
  }
}

/* TDA: Usage */
body {
  background: var(--tda-bg-primary);
  color: var(--tda-text-primary);
}

a      { color: var(--tda-accent); }
button { background: var(--tda-accent); color: #fff; }
hr     { border-color: var(--tda-border); }
```

---

## Semantic Colour Rules

```
TDA_SEMANTIC_RULES = [
  "Never name variables by colour (--blue, --red)",
  "Always name by role (--accent, --error, --success)",
  "Never use colour to convey meaning alone",
  "Pair colour with: icon + text + colour for state communication",
  "Status colours stay consistent across light and dark modes"
]
```

---

## Colour Checklist

```
TDA_COLOR_CHECKLIST = [
  "All text has >= 4.5:1 contrast (WCAG AA)",
  "Large text has >= 3:1 contrast",
  "Colour is never the only way to communicate state",
  "Dark mode reduces saturation slightly (not pure inversion)",
  "Neutral backgrounds are tinted toward brand hue",
  "Accent colour <= 10% of surface (Restrained mode)",
  "Palette is limited: <= 7 total colours (Restrained/Committed)",
  "All colours defined in CSS variables (no hardcoded hex)",
  "Chroma is reduced at extreme lightness values",
  "No pure #000 or #fff anywhere"
]
```

---

## Palette Template

```
TDA_PALETTE_TEMPLATE:

PROJECT: [Name]
BRAND HUE: [0–360°]
STRATEGY LEVEL: [Restrained / Committed / Full / Drenched]

NEUTRALS (tinted toward brand hue)
  Near-white:  oklch(98% 0.002 [hue])
  Light:       oklch(85% 0.01 [hue])
  Medium:      oklch(55% 0.03 [hue])
  Dark:        oklch(25% 0.01 [hue])
  Near-black:  oklch(12% 0.005 [hue])

ACCENT (Primary)
  Saturated:  oklch(55% 0.15 [hue])
  Muted:      oklch(55% 0.08 [hue])
  Subtle:     oklch(90% 0.04 [hue])

STATUS
  Success:    oklch(70% 0.18 155)
  Warning:    oklch(70% 0.15 65)
  Error:      oklch(55% 0.18 25)
  Info:       oklch(60% 0.1 263)

DARK MODE DELTA
  Background: oklch(15% 0.005 [hue])
  Text:       oklch(95% 0.005 [hue])
  Accent:     oklch(60% 0.14 [hue])   (brighter, slightly less saturated)
```

---

**TDA-color.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
