---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Critique & Audit
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-critique-audit
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Heuristic design critique (5-dimension scoring) and full technical
  audit covering accessibility, performance, responsive design,
  and SEO. Includes the AI Slop Test and the TDA Absolute Bans list.

triggers:
  - critique | audit | review | heuristic | quality check
  - polish | improve | is this good | what's wrong | feedback
  - a11y | accessibility | performance | responsive | SEO
---

# TDA: Critique & Audit

---

## Part A: 5-Dimension Heuristic Critique

Score each dimension 1–5. Write one to two sentences justifying the grade. Write a prescription for anything scoring ≤4.

### Dimension 1: Philosophy

*Does the design reflect the brief's intent?*

**Questions:**
- Is this the right visual direction for the users and context?
- Does it ladder up to the product or brand strategy?
- Would someone who read the brief recognise this design immediately?

**Scoring:**
```
5: Design perfectly embodies the brief. No ambiguity.
4: Clearly reflects brief. Minor tweaks sharpen it.
3: Reasonable but not intentional enough.
2: Misses the brief or contradicts it.
1: Completely ignores the brief.
```

**Red flags:**
- Reflex palette (navy + gold for finance, white + teal for health)
- Generic enough to describe any domain
- Aesthetic chosen from comfort, not from brief

---

### Dimension 2: Hierarchy

*Is information prioritised correctly?*

**Questions:**
- What's the first thing you see? Is that what matters most?
- Can you scan this and understand what it does in ≤3 seconds?
- Are CTAs visually dominant relative to supporting content?

**Scoring:**
```
5: Hierarchy is crystal clear. Users always know where to look first.
4: Clear hierarchy. Minor tweaks improve scanning speed.
3: Hierarchy exists but isn't immediately obvious.
2: Multiple elements compete for attention.
1: No clear hierarchy. Everything feels equally important.
```

**Red flags:**
- All text at same size and weight
- CTA buried or ambiguous
- Supporting content more prominent than primary content

---

### Dimension 3: Execution

*Are craft details locked in?*

**Questions:**
- Is spacing rhythmic or arbitrary?
- Are alignments intentional or accidental?
- Does typography have clear hierarchy (≥1.25 ratio between steps)?
- Do all elements feel like they belong together?

**Scoring:**
```
5: Every detail feels intentional. Premium and polished.
4: Strong execution. Minor tweaks improve cohesion.
3: Decent execution. Some details feel rough.
2: Many details unfinished or misaligned.
1: Little attention to craft. Feels rushed.
```

**Red flags:**
- Inconsistent spacing (10px here, 20px there, 7px somewhere else)
- Unintentional optical misalignment
- Fonts that don't coordinate
- Colours that clash
- Inconsistent component sizing

---

### Dimension 4: Function

*Does it actually work?*

**Questions:**
- Are all interactive states designed (hover, focus, active, disabled, error, loading)?
- Does it scale to long and short content?
- Are touch targets ≥44×44px?
- Does it work on all required devices?

**Scoring:**
```
5: All states designed and tested. Works across all devices.
4: Most states covered. Minor responsive issues.
3: Core works. Some states missing or rough.
2: Key states missing. Responsive broken at some sizes.
1: Major functionality broken. Untested on other devices.
```

**Red flags:**
- Hover-only functionality
- Mobile layout broken
- Error states not designed
- Text overflows at any size
- No focus indicator
- Inaccessible form labels

---

### Dimension 5: Innovation

*Is there something new or unexpected?*

**Questions:**
- Does this look different from what competitors do?
- Is there a memorable or distinctive visual move?
- If someone saw this without context, would they remember it?

**Scoring:**
```
5: Distinctive and memorable. Immediately recognisable.
4: Has a unique voice. Some memorable elements.
3: Follows conventions competently. Some unique touches.
2: Mostly conventional. Few distinctive elements.
1: Indistinguishable from anything else in this category.
```

**Red flags:**
- Identical card layouts
- Hero-metric template
- SaaS cream colour palette
- No personality or voice

---

### How to Use It

**Step 1: Score**

Grade each 1–5. One to two sentences justifying each.

**Step 2: Total**

```
TDA_CRITIQUE_SCALE = {
  "23–25": "Exhibition quality. Ship immediately.",
  "20–22": "Production-ready. Minor tweaks acceptable.",
  "17–19": "Good work. Focused refinement needed.",
  "14–16": "Competent but rough. Significant iteration needed.",
  "<14":   "Not ready. Major rework required."
}
```

**Step 3: Prescriptions**

For each dimension scoring ≤4, write one actionable recommendation.

---

### Critique Template

```
## TDA Design Critique: [Feature Name]

### Philosophy (_/5)
[1–2 sentences]

Prescription: [if needed]

---

### Hierarchy (_/5)
[1–2 sentences]

Prescription: [if needed]

---

### Execution (_/5)
[1–2 sentences]

Prescription: [if needed]

---

### Function (_/5)
[1–2 sentences]

Prescription: [if needed]

---

### Innovation (_/5)
[1–2 sentences]

Prescription: [if needed]

---

### Overall: _/25

Status: [Exhibition / Production-ready / Needs refinement / Not ready]

Recommendation: [One paragraph]
```

---

## Part B: Technical Audit

### Accessibility (a11y)

```
TDA_A11Y_CHECKLIST = [
  "All text >= 4.5:1 contrast ratio (WCAG AA)",
  "Large text (>=18px or >=14px bold) >= 3:1 contrast",
  "Form inputs have visible labels or aria-label",
  "All interactive elements keyboard accessible",
  "Tab order is logical and visible",
  "Focus indicator visible on all interactive elements",
  "Images have meaningful alt text (or alt='' if decorative)",
  "Colour is not the only way to communicate state",
  "Motion respects prefers-reduced-motion",
  "Heading hierarchy is correct (h1 > h2 > h3, no skips)",
  "Links distinguishable from regular text",
  "Buttons look clickable"
]
```

**Testing tools:** axe DevTools, WAVE, Lighthouse a11y tab.

---

### Performance

```
TDA_PERF_CHECKLIST = [
  "Lighthouse Performance score >= 80 mobile, >= 90 desktop",
  "LCP (Largest Contentful Paint) <= 2.5s",
  "FID (First Input Delay) <= 100ms",
  "CLS (Cumulative Layout Shift) <= 0.1",
  "No oversized images (correct dimensions + 2x for retina)",
  "Images in modern format (WebP or vector)",
  "No render-blocking JS or CSS in critical path",
  "Fonts use font-display: swap",
  "No unnecessary animations or scrolljacking",
  "Third-party scripts async or deferred"
]
```

**Testing tools:** Lighthouse, WebPageTest, Chrome DevTools.

---

### Responsive Design

```
TDA_RESPONSIVE_CHECKLIST = [
  "Layout adapts compositionally, not just shrinks",
  "Body text measure 50–75 characters at all sizes",
  "Touch targets >= 44x44px on mobile",
  "No horizontal scroll on any viewport",
  "Images don't overflow or crop unexpectedly",
  "Navigation usable on mobile",
  "Form inputs full-width on mobile",
  "No content overlap at any size",
  "Whitespace scales appropriately (not massive gaps on mobile)"
]
```

**Test at:** 375px (narrow mobile), 768px (tablet), 1440px (desktop).

---

### SEO Basics

```
TDA_SEO_CHECKLIST = [
  "Unique descriptive <title> (50–60 characters)",
  "<meta name='description'> is 150–160 chars and compelling",
  "H1 exists and is unique per page",
  "Images have meaningful alt text",
  "Mobile-first responsive design",
  "No duplicate content across pages",
  "Internal links use descriptive anchor text",
  "Page loads in < 3s on 4G"
]
```

---

## Part C: The AI Slop Test

If someone sees it and immediately says "AI made that" without doubt, it failed.

**First-altitude check:** Can they guess the palette from the domain alone?

```
FAIL examples:
  Healthcare → white + teal
  Fintech → navy + gold
  Wellness → sage green + beige
  AI startup → dark + purple gradient
```

**Second-altitude check:** Can they guess the aesthetic from category + anti-references?

```
FAIL example:
  "Fintech that's not navy-gold" → terminal dark mode
  (Still a training-data reflex. Still fails.)
```

Both checks must fail before you proceed.

---

## Part D: Absolute Bans Check

Run this before any `critique` or `audit` task. Flag and prescribe rewrites for any matches.

```javascript
// TDA: Banned patterns — flag and rewrite, do not ship
const TDA_BANNED = {
  'side-stripe-border': {
    pattern: 'border-left or border-right > 1px on card/alert',
    description: 'Dated, lazy visual pattern. Use full border, tint, or icon instead.',
    fix: 'Replace with full border + background tint, or remove entirely.',
  },
  'gradient-text': {
    pattern: 'background-clip: text + linear/radial gradient',
    description: 'Overused. Fails accessibility. Can break on some browsers.',
    fix: 'Use solid colour. Emphasise via weight, size, or case instead.',
  },
  'default-glassmorphism': {
    pattern: 'backdrop-filter: blur on cards as decoration',
    description: 'Glassmorphism is context-specific. Not a default aesthetic.',
    fix: 'Remove blur. Use clean solid backgrounds. Save blur for intentional layering.',
  },
  'hero-metric-template': {
    pattern: 'Large number + label + supporting stats + gradient background',
    description: 'SaaS cliché. Immediately recognisable as template-work.',
    fix: 'Redesign the data presentation with actual hierarchy and intent.',
  },
  'identical-card-grid': {
    pattern: 'Same card component repeated endlessly in a grid',
    description: 'No visual rhythm. No hierarchy. No reason to read any over others.',
    fix: 'Vary card sizes, content density, or structure. Or use a different pattern.',
  },
  'modal-as-first-thought': {
    pattern: 'Modal triggered without considering inline alternatives',
    description: 'Modals interrupt. Usually laziness, not design.',
    fix: 'Try inline expansion, side panel, or progressive disclosure first.',
  },
  'em-dash-in-copy': {
    pattern: 'Em dash (—) in UI copy or labels',
    description: 'Informal in UI context. Harder to read at small sizes.',
    fix: 'Use comma, colon, semicolon, or parentheses instead.',
  },
};
```

---

## Part E: Red Flags Quick List

### Philosophy Smells
- Colour palette could describe any domain
- Design could fit any competitor's product
- No visual personality or voice
- Follows an obvious template

### Hierarchy Issues
- Multiple elements fighting for attention
- CTA not visually dominant
- Can't understand the interface in ≤3 seconds
- Secondary content more prominent than primary

### Execution Problems
- Inconsistent spacing or alignment
- No clear font size hierarchy
- Colours that clash or feel random
- Components that don't feel like they belong together
- Some details polished, others rough

### Functionality Gaps
- Missing hover states
- Mobile layout broken
- Error states not designed
- Text overflows on any size
- No focus indicator
- Keyboard navigation broken

### Innovation Gaps
- Indistinguishable from competitors
- Generic hero + text layout
- Standard repeated card grid
- No memorable visual moves
- Would vanish on Dribbble

---

**TDA-critique-audit.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
