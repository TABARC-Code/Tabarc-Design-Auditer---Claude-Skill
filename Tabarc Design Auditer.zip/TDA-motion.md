---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Motion Design
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-motion
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Motion design expertise for TDA. Physics-first animation,
  14 critical pitfalls, easing library, timing guidelines,
  and seekable animation architecture.

triggers:
  - animate | animation | motion | transition | choreography
  - overdrive | interactive | scroll | keyframe | rAF
  - timing | easing | bounce | stagger | sequence
---

# TDA: Motion Design

> You are not tweaking CSS timings. You are modelling a physical world.
> The viewer's subconscious should believe the screen is a space with weight, inertia, and consequence.

---

## Five Core Beliefs

### 1. Animation Is Physics, Not Curves

`linear` is a number. `easeOutQuart` is a physical object with mass and friction.

Easing answers a physics question: *How heavy is this element? What friction resists it?*

Never pick an easing curve because "it looks smooth." Pick it because it answers a physical question.

```javascript
// TDA: Easing as physics metaphor
// Heavy object (high mass, some friction)
const easeOutQuart = t => 1 - Math.pow(1 - t, 4);

// Lighter paper drift (low mass, more air resistance)
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);

// Feather (barely any mass)
const easeOutExpo = t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
```

### 2. Timing Matters More Than Curve Shape

Rhythm = breathing. Slow-Fast-Boom-Stop.

**Rhythmic animation = narrative. Uniform animation = tech demo.**

The right pause at the right moment beats perfect easing at the wrong moment.

```
TDA_RHYTHM_TEMPLATE = {
  setup:      "0ms",
  slow_intro: "0–400ms",   // viewer expects something
  fast_move:  "400–800ms", // climax
  result:     "800ms",
  pause:      "800–1100ms",// viewer processes (minimum 300ms)
  next_action:"1100ms+"
}
```

### 3. Restraint Over Spectacle

Pausing 0.5 seconds before a key result is **technique**, not compromise.

AI defaults to information-density-maxed, no-pause animations. TDA creates space.

**Rule:** Use animation for state change and attention guidance. Not decoration.

### 4. Beauty Is Observable

When they see your animation:
- They **feel weight** (elements "land," not "stop")
- They **get pause** (≥300ms before key info)
- They **see restraint** (one polished moment; rest is 80% right)
- They **feel hand** (arcs not straight lines; natural rhythm)

**Test:** If someone could say "AI made this" immediately, it's not intentional enough.

### 5. Respect Process

Show tweaks. Show fixes. Don't hide work. Collaborator, not magician.

---

## 14 Critical Motion Pitfalls

### Pitfall 1: Layout Positioning Trap

**Problem:** Child is `position: absolute`, parent isn't `position: relative`. Child floats to document root.

**Symptom:** Animation shifts wildly when you move the parent.

```css
/* TDA: Fix — always anchor absolute children */
.tda-parent {
  position: relative; /* Required for absolute children */
}
.tda-child {
  position: absolute;
  top: 10px;
  left: 20px;
}
```

---

### Pitfall 2: Rare Unicode Characters Don't Render

**Problem:** You use `␣` (U+2423) or `⌨` (keyboard symbol). Font doesn't have them. Renders blank.

**Symptom:** Invisible spacer elements; layout breaks silently.

```css
/* TDA: Fix — CSS-constructed boxes, not Unicode glyphs */
.tda-spacer {
  width: 20px;
  height: 1px;
  display: inline-block;
  background: oklch(80% 0.01 263);
}
```

---

### Pitfall 3: Data-Driven Grid Sync

**Problem:** JS sets N items but CSS hardcodes column count. Item N+1 wraps wrong.

**Symptom:** Last item is half-width or overflows grid unexpectedly.

```javascript
// TDA: Fix — sync grid columns with data
function TDA_syncGrid(container, items) {
  const N = items.length;
  container.style.setProperty('--tda-cols', N);
}
```

```css
/* TDA: CSS uses the variable, not a hardcoded count */
.tda-grid {
  display: grid;
  grid-template-columns: repeat(var(--tda-cols), 1fr);
}
```

---

### Pitfall 4: Transition Gaps Between Scenes

**Problem:** Scene 1 fades out → pause → Scene 2 fades in. Creates blank gap that looks frozen.

**Symptom:** Stuttering, unresponsive feeling between transitions.

```javascript
// TDA: Fix — cross-fade; start Scene 2 before Scene 1 finishes
function TDA_crossfade(scene1, scene2, duration = 600) {
  // Start both simultaneously; CSS handles overlap
  scene1.style.transition = `opacity ${duration}ms ease-out`;
  scene2.style.transition = `opacity ${duration}ms ease-in`;

  scene1.style.opacity = '0';
  scene2.style.opacity = '1'; // Start immediately; no gap
}
```

---

### Pitfall 5: Animation State Must Be Seekable

**Problem:** `setTimeout` chains work on playback but break on seek. Previous timeouts already fired; state is wrong.

**Symptom:** Seeking to 50% shows wrong state; manual scrubbing breaks.

```javascript
// TDA: Fix — render(t) is a pure function.
// Given time t (0–1), output is always deterministic.

const TDA_firedOnce = new Set();

function TDA_fireOnce(key, fn) {
  if (!TDA_firedOnce.has(key)) {
    TDA_firedOnce.add(key);
    fn();
  }
}

function TDA_resetFired() {
  TDA_firedOnce.clear();
}

// Pure render — always seekable
function TDA_render(t) {
  TDA_resetFired();
  // Reconstruct all DOM state from t
  // No side effects outside of DOM
}

// Expose seek globally for debugging
window.TDA_seek = t => TDA_render(t);
```

---

### Pitfall 6: Font Loading Breaks Measurements

**Problem:** `getBoundingClientRect()` called before fonts load. Fallback font widths are wrong. Positions break.

**Symptom:** Text shifts after animation; layout breaks when fonts swap in.

```javascript
// TDA: Fix — always measure inside document.fonts.ready
document.fonts.ready.then(() => {
  // TDA: Fonts loaded. Measurements are now correct.
  const rect = document.querySelector('.tda-text').getBoundingClientRect();
  TDA_animateFromRect(rect);
});
```

---

### Pitfall 7: Floating-Point Accumulation Errors

**Problem:** `x += 0.1` per frame × 60fps × 10s = drift. Element ends 2px off target.

**Symptom:** Animations creep off-target over time.

```javascript
// TDA: Fix — recalculate from t, never accumulate

// Bad (accumulates error)
let x = 0;
function badFrame() { x += 0.1; el.style.left = x + 'px'; }

// Good (pure, always exact)
function TDA_render(t, duration = 10000) {
  const progress = t / duration;
  el.style.left = (progress * 1000) + 'px'; // Always recalculated from scratch
}
```

---

### Pitfall 8: Stagger Ordering Separates Parent and Child

**Problem:** Parent animates; staggered children lag behind. They separate visually.

**Symptom:** Children fall behind parent mid-animation; group splits apart.

```css
/* TDA: Fix — children move within parent's transform space */
.tda-parent {
  transition: transform 0.6s ease-out;
}
.tda-child {
  /* Relative to parent — won't separate */
  transition: transform 0.4s ease-out 0.1s; /* Slight stagger is fine */
}
```

---

### Pitfall 9: SVG Coordinate System Surprises

**Problem:** Inline SVG inside transformed div. SVG `viewBox` ≠ div size. Content shifts unpredictably.

**Symptom:** SVG elements appear in wrong positions under transforms.

```html
<!-- TDA: Fix — always explicit viewBox and preserveAspectRatio -->
<svg
  viewBox="0 0 1200 600"
  preserveAspectRatio="xMidYMid meet"
  width="600"
  height="300"
  xmlns="http://www.w3.org/2000/svg">
  <!-- content -->
</svg>
```

---

### Pitfall 10: Z-Index Stacking Context Trap

**Problem:** Child has `z-index: 9999` but parent's stacking context caps it.

**Symptom:** "Why won't my modal appear on top?"

```css
/* TDA: Fix — restructure or set position on both */

/* Bad — z-index trapped inside parent's context */
.tda-parent { /* no stacking context */ }
.tda-modal { z-index: 9999; } /* Only competes within parent */

/* Good — parent also in correct stacking context */
.tda-container { position: relative; z-index: 100; }
.tda-modal { z-index: 101; } /* Competes correctly */

/* Or use fixed positioning to escape all contexts */
.tda-portal { position: fixed; z-index: 9999; }
```

---

### Pitfall 11: Canvas Context Transform Accumulation

**Problem:** `ctx.translate()` and `ctx.rotate()` calls accumulate. Drawing position drifts.

**Symptom:** Canvas drawing ends up in wrong place; rotations stack unexpectedly.

```javascript
// TDA: Fix — always save/restore around transforms
function TDA_drawElement(ctx, x, y, angle) {
  ctx.save();              // TDA: Snapshot transform state
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.drawImage(img, -50, -50, 100, 100);
  ctx.restore();           // TDA: Reset to snapshot; no accumulation
}
```

---

### Pitfall 12: RequestAnimationFrame Timing Surprises

**Problem:** Animation assumes exact 60fps. rAF frequency varies by device load.

**Symptom:** Animation runs at wrong speed; stutters on busy frames.

```javascript
// TDA: Fix — measure elapsed time from startTime, always

let TDA_startTime = null;

function TDA_animLoop(currentTime) {
  if (!TDA_startTime) TDA_startTime = currentTime;

  const elapsed = currentTime - TDA_startTime; // ms since start
  const progress = Math.min(elapsed / 2000, 1); // 2s duration

  TDA_render(progress);

  if (progress < 1) {
    requestAnimationFrame(TDA_animLoop);
  }
}

requestAnimationFrame(TDA_animLoop);
```

---

### Pitfall 13: Transform-Origin Default Surprises

**Problem:** Elements rotate around top-left, not centre.

**Symptom:** Element spins off-axis; looks broken.

```css
/* TDA: Fix — always explicit transform-origin */
.tda-rotating {
  transform-origin: center center; /* Never assume default */
  transform: rotate(45deg);
}

/* For orbit animations */
.tda-orbiting {
  transform-origin: 0px 100px; /* Custom pivot point */
}
```

---

### Pitfall 14: Overflow Hidden Creates Stacking Context

**Problem:** `overflow: hidden` traps z-index. Children can't appear outside parent.

**Symptom:** Dropdowns or tooltips get clipped; z-index ignored.

```css
/* TDA: Fix — portal pattern for elements that must escape overflow */

/* Remove overflow: hidden if not needed for the clipping */
.tda-container {
  /* overflow: hidden; */ /* Removed: was trapping dropdown */
  position: relative;
}

/* Or: render dropdown outside the overflow container (portal) */
.tda-dropdown-portal {
  position: fixed; /* Escapes all overflow contexts */
  z-index: 9999;
}
```

---

## TDA Easing Library

```javascript
// ============================================================
// TDA: Easing Curves
// All curves are pure functions: t in [0,1] → value in [0,1]
// ============================================================

const TDA_ease = {

  // Production default for heavy objects
  outExpo:      t => t === 1 ? 1 : 1 - Math.pow(2, -10 * t),

  // Confident landing
  outQuart:     t => 1 - Math.pow(1 - t, 4),

  // Extra heavy
  outQuint:     t => 1 - Math.pow(1 - t, 5),

  // Gentle, natural
  outCubic:     t => 1 - Math.pow(1 - t, 3),

  // Quick, light
  outQuad:      t => 1 - (1 - t) * (1 - t),

  // No character (for data/opacity)
  linear:       t => t,

  // Slow start, fast middle, slow end
  inOutCubic:   t => t < 0.5
                  ? 4 * t * t * t
                  : 1 - Math.pow(-2 * t + 2, 3) / 2,

  // Use sparingly; can feel playful or cheap
  outElastic:   t => {
    const c = (2 * Math.PI) / 4.5;
    return t === 0 ? 0 : t === 1 ? 1
      : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c) + 1;
  },
};

// Usage
function TDA_render(progress) {
  const x = TDA_ease.outQuart(progress) * 900;
  el.style.transform = `translateX(${x}px)`;
}
```

---

## Timing Guidelines

| Duration | Use Case | Feel |
|---|---|---|
| 100–150ms | Micro-interactions (hover, icon change) | Snappy, responsive |
| 200–300ms | State transitions (modal, form error) | Quick but intentional |
| 400–600ms | Full transitions (page nav, scene change) | Confident, weighty |
| 800ms–1.2s | Choreography (multi-step sequences) | Deliberate, narrative |
| ≥1.5s | Storytelling or demo mode only | Intentionally slow |

**Sweet spot:** 300–600ms. Faster = cheap. Slower = frustrating.

---

## Reduced Motion

Always respect the user's preference.

```css
/* TDA: Reduced motion override */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

```javascript
// TDA: Check in JS before starting animation
const TDA_prefersReducedMotion = window.matchMedia(
  '(prefers-reduced-motion: reduce)'
).matches;

if (!TDA_prefersReducedMotion) {
  TDA_startAnimation();
} else {
  TDA_showFinalState(); // Skip animation; show end state directly
}
```

---

## Motion Critique Checklist

Before shipping:

```
TDA_MOTION_CHECKLIST = [
  "Does this animate state change or guide attention? (Not decoration)",
  "Is the easing choice justified by physics?",
  "Is there a pause >= 300ms before the key moment?",
  "Does it respect prefers-reduced-motion?",
  "Is it smooth at 60fps on target devices?",
  "Does it work at all viewport sizes?",
  "Can you explain it in one sentence?",
  "Would it feel native in a Stripe or Apple product?"
]
```

---

## Starter: Seekable Animation Loop

```javascript
// ============================================================
// TDA: Seekable Animation Loop
// Core architecture: pure render function + time measurement
// ============================================================

function TDA_createLoop({ duration = 2000, onRender, onComplete } = {}) {
  let startTime = null;
  let isPlaying = false;
  let rafId = null;

  function loop(currentTime) {
    if (!isPlaying) return;
    if (!startTime) startTime = currentTime;

    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);

    // TDA: Pure render — deterministic output for any progress value
    if (onRender) onRender(progress);

    if (progress < 1) {
      rafId = requestAnimationFrame(loop);
    } else {
      isPlaying = false;
      if (onComplete) onComplete();
    }
  }

  return {
    play() {
      if (isPlaying) return;
      isPlaying = true;
      startTime = null;
      rafId = requestAnimationFrame(loop);
    },
    pause() {
      isPlaying = false;
      if (rafId) cancelAnimationFrame(rafId);
    },
    reset() {
      this.pause();
      startTime = null;
      if (onRender) onRender(0);
    },
    // TDA: seek() — pure; call onRender directly with any t
    seek(t) {
      this.pause();
      if (onRender) onRender(Math.max(0, Math.min(1, t)));
    },
  };
}

// Usage:
const anim = TDA_createLoop({
  duration: 1500,
  onRender(t) {
    const x = TDA_ease.outQuart(t) * 800;
    el.style.transform = `translateX(${x}px)`;
  },
  onComplete() {
    console.log('TDA: Animation complete');
  },
});

anim.play();
```

---

**TDA-motion.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
