---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Slide Deck Design
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-slides
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Presentation design expertise for TDA. Format decision gate,
  grammar lock-in workflow, PPTX constraints, keyboard navigation,
  slide anatomy, and complete starter framework.

triggers:
  - slide | slides | deck | presentation | pitch | keynote
  - powerpoint | PPTX | PDF export | lecture | webinar
  - report | brochure | campaign deck | business presentation
---

# TDA: Slide Deck Design

> Slides are not apps. Slides are storytelling through time.
> In apps, users control pacing. In slides, you control pacing.
> Every slide must answer: what does this teach that the last one didn't?

---

## Format Decision Gate

**Confirm the output format before touching anything.**

```
TDA_SLIDES_GATE = {
  "HTML only":         "Full visual freedom. Browser-native. No constraints.",
  "HTML + PDF":        "Same HTML. One export command. For print/sharing.",
  "HTML + PPTX":       "Severe visual constraints apply. User must acknowledge."
}
```

Say this to the user:

> "I build HTML first. It plays in any browser with keyboard navigation, no dependencies, no PowerPoint required. Depending on what you need:
>
> - **Just HTML?** Full visual freedom. Done.
> - **Plus PDF?** One export command. Same HTML.
> - **Plus editable PPTX?** I must build with constraints from line 1: no gradients, no web components, all text in `<p>` tags. You can edit the text in PowerPoint later.
>
> Which do you need?"

### PPTX Constraints

If the user chooses editable PPTX, enforce all four rules from the very first line of code:

```javascript
// TDA: PPTX constraint enforcement
// Violating any of these breaks PowerPoint export

const TDA_PPTX_RULES = {
  canvas_size:       "960pt × 540pt (not pixels)",
  text_containers:   "All text must be in <p> or <h1>–<h6>",
  text_decoration:   "No background/border/shadow on text elements",
  imagery:           "Use <img> tags. No background-image. No gradients.",
  web_components:    "None. No custom elements, no complex SVG.",
};
```

**When the user wants visual complexity AND editable PPTX:**

Be direct:

> "Those two goals conflict. Gradients and complex layouts can't export to editable PPTX. Which matters more: visual quality or PowerPoint editability? Pick one. I won't try to do both."

---

## Format Comparison

| Format | Pros | Cons | Best For |
|---|---|---|---|
| HTML only | Full visual freedom, keyboard nav, live demos | Can't edit in PowerPoint | Default choice for designers |
| HTML + PDF | Printable, shareable, same HTML | Can't edit content | Sharing with print-first users |
| HTML + editable PPTX | Stakeholders can edit text/order | Severe visual constraints | Client handoffs |

---

## Grammar Lock-In Workflow

Never write 13 slides then iterate. Always follow this sequence.

### Step 1: Create 2 Showcase Slides

Pick slides that are visually different from each other:

```
TDA_SHOWCASE_PAIRS = {
  "B2B brochure":    ["cover slide", "content page"],
  "data report":     ["hero stat page", "analysis page"],
  "course deck":     ["chapter title", "lesson content"],
  "pitch deck":      ["problem slide", "solution slide"],
  "product launch":  ["hero slide", "feature detail"],
}
```

### Step 2: Polish Those 2 Ruthlessly

Lock in every grammar decision:

```
TDA_GRAMMAR_LOCK = {
  H1:        "96px, font, weight, colour strategy",
  body:       "24px, font, line-height, measure",
  grid:       "margin values, gutter size",
  accent:     "max highlights per slide",
  background: "colour, texture, weight",
  spacing:    "base increment (all gaps are multiples of this)",
}
```

### Step 3: Get User Approval

User approves the 2 showcase slides. Grammar is locked.

### Step 4: Batch-Produce

Use the locked grammar for all remaining slides. Only add new patterns if they fit the grammar without breaking it. Ask before adding new patterns.

**Why:** Refactoring 2 wrong-direction slides is fast. Refactoring 13 is not.

---

## Slide Anatomy

```
┌── Masthead (logo, issue, date) ──────────────────────┐
├──────────────────────────────────────────────────────┤
│                                                      │
│  SECTION LABEL (small caps, accent, 12–14px)        │
│                                                      │
│  H1 — Main Heading                                  │
│  Key words in brand colour                          │
│  96–140px, serif, 1.1 line-height                   │
│                                                      │
│  Subtitle or supporting line                        │
│  italic, 28–40px, secondary font                   │
│  ──────────────────────────────                     │
│                                                      │
│  [Content]                                          │
│  Grid, 2-column, asymmetric, image+text             │
│                                                      │
├──────────────────────────────────────────────────────┤
│  Section Name                           XX / Total   │
└──────────────────────────────────────────────────────┘
```

### Style Values

```css
/* TDA: Slide typography defaults */

/* H1 */
.tda-slide h1 {
  font-size: 96px;         /* Up to 140px for impact */
  font-weight: 700;
  font-family: Georgia, serif; /* Or brand display font */
  line-height: 1.1;
  color: oklch(20% 0.01 263);
}

/* Key word accent */
.tda-slide h1 .tda-accent {
  color: oklch(55% 0.15 263); /* Brand colour */
}

/* Subtitle */
.tda-slide .tda-subtitle {
  font-style: italic;
  font-size: 28px;         /* Up to 40px */
  font-family: Georgia, serif;
  color: oklch(45% 0.02 263);
  line-height: 1.3;
}

/* Body */
.tda-slide p {
  font-size: 21px;
  line-height: 1.8;
  color: oklch(35% 0.02 263);
  max-width: 900px;
}

/* Section label */
.tda-slide .tda-label {
  font-size: 13px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: oklch(60% 0.08 263);
}

/* Background */
.tda-slide {
  background: oklch(98% 0.003 263); /* Warm off-white, tinted */
}

/* Slide whitespace target: 60%+ */
/* Silence = credibility in presentations */
```

---

## Keyboard Navigation (Required)

Every deck must support these keys:

```javascript
// TDA: Slide keyboard navigation
document.addEventListener('keydown', e => {

  // Forward
  if (e.key === 'ArrowRight' || e.key === ' ') {
    TDA_slides.next();
    e.preventDefault();
  }

  // Back
  if (e.key === 'ArrowLeft') {
    TDA_slides.prev();
    e.preventDefault();
  }

  // Jump to slide by number
  if (/^\d$/.test(e.key)) {
    const target = parseInt(e.key) - 1;
    if (target >= 0 && target < TDA_slides.total) {
      TDA_slides.goTo(target);
    }
  }

  // Toggle menu (if available)
  if (e.key === 'Escape') {
    TDA_slides.toggleMenu?.();
  }
});
```

---

## Copy Discipline

```
TDA_COPY_RULES = [
  "Every word earns its place",
  "No restated headings (title says it; body doesn't repeat it)",
  "No em dashes in slide copy",
  "Short, active sentences",
  "Max 2 lines per bullet",
  "Max 5 bullets per slide (prefer fewer)",
  "Headline: the argument, not the topic",
  "One claim per slide"
]
```

---

## Content Patterns by Deck Type

### Data / Report

```
TDA_DATA_PATTERNS = {
  "hero-stat":    "Large number (80px+) + one-line context. No busy charts.",
  "analysis":     "Smaller number + title + chart or visual proof",
  "proof-points": "3 boxes: icon + stat. Vary spacing slightly.",
}
```

### Pitch

```
TDA_PITCH_PATTERNS = {
  "problem":    "Image or illustration + one sentence + supporting detail",
  "solution":   "Product image + benefit statement + supporting detail",
  "traction":   "Chart or metric + context + one supporting stat",
}
```

### Educational / Course

```
TDA_EDU_PATTERNS = {
  "chapter-intro":    "Chapter title (large serif) + 3 objectives + preview",
  "lesson":           "Title + explanation (1–2 paragraphs max) + example",
  "key-takeaway":     "One sentence (impactful) + icon + optional detail",
}
```

---

## Starter: Minimal Deck Framework

```html
<!DOCTYPE html>
<!-- TDA: Slide Deck Framework v1.0 -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Presentation</title>
  <style>
    /* TDA: Reset */
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: oklch(15% 0.005 263);
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    /* TDA: Deck wrapper */
    .tda-deck-wrap {
      position: relative;
      width: 1920px;
      height: 1080px;
    }

    /* TDA: Slide base state */
    .tda-slide {
      position: absolute;
      inset: 0;
      padding: 80px;
      display: none;
      flex-direction: column;
      justify-content: center;
      background: oklch(98% 0.003 263);
    }

    .tda-slide.active {
      display: flex;
    }

    /* TDA: Typography */
    .tda-slide h1 {
      font-size: 96px;
      font-weight: 700;
      line-height: 1.1;
      color: oklch(20% 0.01 263);
      margin-bottom: 24px;
    }

    .tda-slide h1 .tda-accent {
      color: oklch(55% 0.15 263);
    }

    .tda-slide p {
      font-size: 24px;
      line-height: 1.75;
      color: oklch(40% 0.02 263);
      max-width: 900px;
    }

    /* TDA: Footer */
    .tda-footer {
      position: absolute;
      bottom: 32px;
      left: 80px;
      right: 80px;
      display: flex;
      justify-content: space-between;
      font-size: 13px;
      color: oklch(65% 0.01 263);
      letter-spacing: 0.5px;
    }

    /* TDA: Controls */
    .tda-controls {
      position: fixed;
      bottom: 32px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      gap: 16px;
      background: oklch(99% 0.002 263);
      padding: 14px 28px;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
      z-index: 100;
    }

    .tda-btn {
      background: oklch(55% 0.15 263);
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 600;
      transition: background 0.15s;
    }

    .tda-btn:hover { background: oklch(48% 0.15 263); }

    .tda-count {
      font-size: 13px;
      color: oklch(50% 0.01 263);
      min-width: 56px;
      text-align: center;
    }
  </style>
</head>
<body>

<!-- TDA: Deck -->
<div class="tda-deck-wrap">

  <div class="tda-slide active">
    <h1>Title <span class="tda-accent">Here</span></h1>
    <p>Subtitle or opening context. One idea per slide.</p>
    <div class="tda-footer">
      <span>Tabarc</span>
      <span id="tda-footer-num">1</span>
    </div>
  </div>

  <div class="tda-slide">
    <h1>Second <span class="tda-accent">Slide</span></h1>
    <p>Build momentum. Each slide teaches one thing the last one didn't.</p>
    <div class="tda-footer">
      <span>Tabarc</span>
      <span>2</span>
    </div>
  </div>

  <div class="tda-slide">
    <h1>Third <span class="tda-accent">Slide</span></h1>
    <p>End on something worth remembering. Not a summary. A conclusion.</p>
    <div class="tda-footer">
      <span>Tabarc</span>
      <span>3</span>
    </div>
  </div>

</div>

<!-- TDA: Navigation -->
<div class="tda-controls">
  <button class="tda-btn" onclick="TDA_deck.prev()">&#8592; Back</button>
  <span class="tda-count">
    <span id="tda-current">1</span> / <span id="tda-total"></span>
  </span>
  <button class="tda-btn" onclick="TDA_deck.next()">Next &#8594;</button>
</div>

<script>
  // TDA: Deck controller
  const TDA_deck = (() => {
    let current = 0;
    const slides = document.querySelectorAll('.tda-slide');
    const total = slides.length;

    document.getElementById('tda-total').textContent = total;

    function show(n) {
      slides[current].classList.remove('active');
      current = (n + total) % total;
      slides[current].classList.add('active');
      document.getElementById('tda-current').textContent = current + 1;
    }

    // Keyboard navigation
    document.addEventListener('keydown', e => {
      if (e.key === 'ArrowRight' || e.key === ' ') { show(current + 1); e.preventDefault(); }
      if (e.key === 'ArrowLeft') { show(current - 1); e.preventDefault(); }
      if (/^\d$/.test(e.key)) {
        const n = parseInt(e.key) - 1;
        if (n >= 0 && n < total) show(n);
      }
    });

    return {
      next:  () => show(current + 1),
      prev:  () => show(current - 1),
      goTo:  (n) => show(n),
      total,
    };
  })();
</script>

</body>
</html>
```

---

## Responsive Slides (Viewport Scaling)

```javascript
// TDA: Scale deck to fill any viewport while preserving aspect ratio
function TDA_scaleDeck() {
  const deck = document.querySelector('.tda-deck-wrap');
  const designWidth = 1920;
  const designHeight = 1080;

  const viewW = window.innerWidth;
  const viewH = window.innerHeight;

  const scale = Math.min(
    viewW / designWidth,
    viewH / designHeight
  );

  deck.style.transform = `scale(${scale})`;
  deck.style.transformOrigin = 'top center';
}

window.addEventListener('resize', TDA_scaleDeck);
TDA_scaleDeck();
```

---

## PDF Export (If Needed)

```bash
# TDA: HTML to PDF via headless Chrome
npx puppeteer print-to-pdf index.html output.pdf

# Or via wkhtmltopdf
wkhtmltopdf --print-media-type \
            --margin-top 0 --margin-bottom 0 \
            --margin-left 0 --margin-right 0 \
            index.html output.pdf
```

```css
/* TDA: Print-specific overrides */
@media print {
  .tda-controls { display: none; }
  .tda-slide { display: flex !important; page-break-after: always; }
  body { background: white; }
}
```

---

**TDA-slides.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
