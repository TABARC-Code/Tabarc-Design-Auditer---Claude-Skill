---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Spatial Design
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-spatial
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Spatial design expertise for TDA. 8px grid, spacing hierarchy,
  optical alignment, grid systems, whitespace management,
  and responsive spacing.

triggers:
  - layout | spacing | grid | rhythm | whitespace
  - alignment | margin | padding | gap | container
  - visual hierarchy | composition | density | structure
---

# TDA: Spatial Design

> Space is not what's left over. Space is the design.
> Most interfaces fail because they fill every pixel.
> The best use 60%+ empty space, arranged deliberately.

---

## The 8px Grid

All spacing, margins, and sizing are multiples of 8px.

```css
/* TDA: Spacing scale */
:root {
  --tda-space-1: 8px;
  --tda-space-2: 16px;
  --tda-space-3: 24px;
  --tda-space-4: 32px;
  --tda-space-5: 40px;
  --tda-space-6: 48px;
  --tda-space-8: 64px;
  --tda-space-10: 80px;
  --tda-space-12: 96px;
}

/* Usage */
.tda-button { padding: var(--tda-space-1) var(--tda-space-2); }
.tda-card   { padding: var(--tda-space-4); }
section     { margin-top: var(--tda-space-8); }
```

---

## Spacing Hierarchy

Not all space is equal. Spacing signals relationships.

```
TDA_SPACING_SEMANTIC = {
  "≤12px":  "Related items (label + input, button + confirm text)",
  "16–32px": "Between sections, between card rows",
  "40px+":  "Between major sections, hero to content"
}
```

### The Rule

If two elements are closely related, space them tightly (8px). If they're independent, space them loosely (32–64px).

```css
/* TDA: Spacing clarifies hierarchy */

/* Tight = same group */
.tda-label    { margin-bottom: var(--tda-space-1); }
.tda-input    { margin-bottom: var(--tda-space-1); }

/* Loose = new group */
.tda-section  { margin-bottom: var(--tda-space-8); }

/* Very loose = major context change */
.tda-hero     { margin-bottom: var(--tda-space-12); }
```

---

## Optical Alignment

Mathematical centering and visual centering are not the same.

```css
/* TDA: Optical centering for icons */
.tda-icon-btn {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Icons often sit slightly low — nudge up */
.tda-icon-btn svg {
  transform: translateY(-1px);
}

/* TDA: Optical text padding in buttons */
.tda-btn {
  /* Mathematical: 12px top, 12px bottom */
  /* Optical: slightly less top (text appears lower than centre visually) */
  padding: 10px 20px 12px; /* Adjust per font */
}
```

---

## Grid Systems

```css
/* TDA: 12-column grid */
.tda-grid-12 {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: var(--tda-space-3); /* 24px */
}

/* TDA: Common column spans */
.tda-col-4  { grid-column: span 4; }   /* 1/3 */
.tda-col-6  { grid-column: span 6; }   /* 1/2 */
.tda-col-8  { grid-column: span 8; }   /* 2/3 */
.tda-col-12 { grid-column: span 12; }  /* full */

/* TDA: Auto-fit grid for collections */
.tda-grid-auto {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: var(--tda-space-2);
}

/* TDA: Responsive overrides */
@media (max-width: 768px) {
  .tda-grid-12 {
    grid-template-columns: repeat(6, 1fr);
  }
}

@media (max-width: 480px) {
  .tda-grid-12 {
    grid-template-columns: 1fr;
  }
}
```

---

## Whitespace Management

**Target: 60% whitespace, 40% content.**

```css
/* TDA: Container with enforced whitespace */
.tda-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 var(--tda-space-5); /* 40px horizontal breathing room */
}

/* TDA: Section vertical rhythm */
.tda-section {
  padding-top: var(--tda-space-10);    /* 80px */
  padding-bottom: var(--tda-space-10);
}

/* TDA: Component breathing room */
.tda-card {
  padding: var(--tda-space-4); /* 32px */
}

/* TDA: List item spacing */
.tda-list li {
  padding: var(--tda-space-2) var(--tda-space-3);
  margin-bottom: var(--tda-space-1);
}
```

---

## Cards: When to Use, When Not To

```
TDA_CARD_USE = {
  good: [
    "Items are independent from each other",
    "Items vary in importance (can be ranked)",
    "Items need elevation to separate from background"
  ],
  bad: [
    "Items are closely related (use a list)",
    "You have hundreds of them",
    "They're all identical (use a different structure)"
  ]
}
```

```css
/* TDA: Card — when it earns its place */
.tda-card {
  padding: var(--tda-space-4);
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  background: oklch(99% 0.002 263);
}

/* TDA: Card spacing (not same as content spacing) */
.tda-card-grid {
  display: grid;
  gap: var(--tda-space-2); /* 16px between cards */
}
```

---

## Responsive Spacing

```css
/* TDA: Section spacing scales down on smaller viewports */
.tda-section {
  margin-top: var(--tda-space-10); /* 80px desktop */
  padding: 0 var(--tda-space-5);   /* 40px horizontal desktop */
}

@media (max-width: 768px) {
  .tda-section {
    margin-top: var(--tda-space-5); /* 40px tablet */
    padding: 0 var(--tda-space-4);  /* 32px horizontal tablet */
  }
}

@media (max-width: 480px) {
  .tda-section {
    margin-top: var(--tda-space-3); /* 24px mobile */
    padding: 0 var(--tda-space-2);  /* 16px horizontal mobile */
  }
}
```

---

## Common Mistakes and Fixes

```css
/* TDA: Fix — cramped cards */
/* Bad */
.card { padding: 8px; }
/* Good */
.tda-card { padding: 32px; }

/* TDA: Fix — no gap between list items */
/* Bad */
li { margin: 0; }
/* Good */
li { margin-bottom: 8px; }

/* TDA: Fix — container stretches on huge screens */
/* Bad */
section { width: 100%; }
/* Good */
section { max-width: 1200px; margin: 0 auto; padding: 0 40px; }

/* TDA: Fix — buttons feel off-centre */
/* Bad: equal top/bottom padding */
.btn { padding: 12px 24px; }
/* Good: optical adjustment */
.btn { padding: 10px 24px 12px; }
```

---

## Spatial Design Checklist

```
TDA_SPATIAL_CHECKLIST = [
  "All spacing uses 8px grid (or 4px for fine control)",
  "Related items are tightly spaced (8–16px)",
  "Unrelated items are loosely spaced (32px+)",
  "Container has max-width (not stretched on wide screens)",
  "Container has generous padding (40px+ desktop, 16px+ mobile)",
  "Heading spacing: larger gap before, smaller gap after",
  "List items have clear breathing room (8–16px apart)",
  "Cards have consistent padding (24–32px)",
  "Major section gaps are large (64px+)",
  "Whitespace is approximately 60% of the design"
]
```

---

**TDA-spatial.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
