---
# ============================================================
# TABARC DESIGN AUDITOR
# Subskill: Typography & Typesetting
# Author: TABARC-Code
# Version: 1.0
# ============================================================
name: TDA-typography
parent: tabarc-design-auditor
version: 1.0
author: TABARC-Code
description: >
  Typography expertise for TDA. Modular scale, weight contrast,
  measure, line height, font pairing, loading, kerning,
  and full readability checklist.

triggers:
  - typeset | typography | font | typeface | measure
  - hierarchy | heading | line-height | kerning | legibility
  - font pairing | type scale | variable font | readability
---

# TDA: Typography & Typesetting

> Typography is not decoration. It is structure.
> A well-typeset interface tells you where to look and how to move through information without any other design support.

---

## Hierarchy Through Scale and Weight

### Modular Scale (1.25 ratio — Minor Third)

```
TDA_TYPE_SCALE_125 = {
  base: "16px",
  h5:   "20px",  // × 1.25
  h4:   "25px",  // × 1.25
  h3:   "31px",  // × 1.25
  h2:   "39px",  // × 1.25
  h1:   "49px",  // × 1.25
}
```

For large displays (≥64px), use 1.5 ratio:

```
TDA_TYPE_SCALE_150 = {
  base:    "16px",
  display: "64px",  // × 4.0
  hero:    "96px",  // × 1.5
  massive: "144px", // × 1.5
}
```

### Weight Contrast

Minimum 100-weight difference between hierarchy levels.

```css
/* TDA: Weight hierarchy */
body { font-weight: 400; }
.tda-label { font-weight: 500; }
.tda-subheading { font-weight: 600; }
h1, h2, h3 { font-weight: 700; }

/* Never: */
h2 { font-size: 18px; font-weight: 500; } /* Too close to body */

/* Always: */
h2 { font-size: 32px; font-weight: 700; } /* Clear jump */
```

---

## Measure (Line Length)

**Body copy: 50–75 characters. Strictly enforced.**

```css
/* TDA: Measure constraint */
.tda-body {
  font-size: 16px;
  line-height: 1.6;
  max-width: 65ch; /* 65 characters */
}

/* For large display text */
.tda-display {
  max-width: 80ch; /* Slightly more latitude */
}
```

---

## Line Height

```
TDA_LINE_HEIGHT = {
  "≥64px heading":   "1.1–1.2",
  "32–48px heading": "1.2–1.3",
  "≤24px heading":   "1.3–1.4",
  "body (14–18px)":  "1.6–1.75",
  "large body":      "1.75–1.85",
  "UI label":        "1.4–1.5"
}
```

---

## Font Pairing Rules

```
TDA_PAIRING_RULES = [
  "Don't mix more than 2 typefaces",
  "Pair a distinctive serif with a neutral sans (maximum contrast)",
  "Or two sansserifs with clear weight and size difference",
  "Never pair two similar fonts (Garamond + Sabon = no contrast)",
  "System stack first for body, web font only for display"
]
```

### System Stack (Default)

```css
/* TDA: System font stack — fastest, most compatible */
.tda-body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI',
               Roboto, Helvetica, Arial, sans-serif;
}

/* Load web fonts ONLY for display text */
.tda-display {
  font-family: 'Playfair Display', Georgia, serif;
  font-display: swap; /* Never block rendering */
}
```

---

## Kerning and Letter Spacing

```css
/* TDA: Kerning standards */

/* Large headings (≥64px) — slightly negative */
.tda-hero { letter-spacing: -1px; }

/* Medium headings — trust the font */
.tda-heading { letter-spacing: 0; }

/* All-caps labels — open spacing */
.tda-label {
  text-transform: uppercase;
  letter-spacing: 1px;
  font-size: 12px;
}

/* Body copy — never touch letter-spacing */
.tda-body { letter-spacing: 0; }
```

---

## Common Problems and Fixes

```css
/* TDA: Fix — cramped body text */
/* Bad */
body { font-size: 16px; line-height: 1.3; max-width: 100%; }
/* Good */
body { font-size: 16px; line-height: 1.6; max-width: 65ch; }

/* TDA: Fix — headings fighting each other */
/* Bad */
h1 { font-size: 28px; font-weight: 600; }
h2 { font-size: 24px; font-weight: 500; }
/* Good */
h1 { font-size: 48px; font-weight: 700; }
h2 { font-size: 28px; font-weight: 600; }
body { font-size: 16px; font-weight: 400; }

/* TDA: Fix — long words break layout */
body {
  overflow-wrap: break-word;
  word-break: break-word;
}
a, code {
  overflow-wrap: break-word;
  word-break: break-all;
}

/* TDA: Fix — font loads late, text shifts */
@font-face {
  font-family: 'TDA-Display';
  src: url('font.woff2') format('woff2');
  font-display: swap; /* Show fallback immediately */
}
```

---

## Readability Checklist

```
TDA_TYPE_CHECKLIST = [
  "Body measure is 50–75 characters",
  "Line height >= 1.5 for body",
  "Heading hierarchy clear: >= 1.25 ratio between sizes",
  "Weight AND size both signal hierarchy",
  "Contrast >= 4.5:1 for body, >= 3:1 for large text",
  "font-display: swap on all custom fonts",
  "Text doesn't overflow on mobile",
  "Long headings break naturally (no awkward word cuts)",
  "Italic and bold visibly distinct from regular",
  "Letter-spacing only on labels, never on body"
]
```

---

**TDA-typography.md — Tabarc Design Auditor**
**Author:** TABARC-Code
**Part of:** tabarc-design-auditor skill set
